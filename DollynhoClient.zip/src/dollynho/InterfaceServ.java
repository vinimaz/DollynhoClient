package dollynho;

import java.rmi.Remote;

/**
 * Created by vinimaz on 5/5/16.
 */
public interface InterfaceServ extends Remote {
}
